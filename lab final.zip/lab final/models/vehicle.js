var mongoose = require("mongoose");

var productSchema = mongoose.Schema({
  registration_number: Number,
  make: String,
  model: String,
  color: String,
});
const Product = mongoose.model("vehicle", productSchema);
module.exports = Product;
